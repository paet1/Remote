plugins {
    id("com.android.application")
}

android {
    namespace = "at.amperae.vlinkerremote"
    compileSdk = 35

    defaultConfig {
        applicationId = "at.amperae.vlinkerremote"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-test"
    }
}

dependencies {
}
