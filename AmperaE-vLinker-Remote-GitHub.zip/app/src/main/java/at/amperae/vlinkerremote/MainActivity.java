package at.amperae.vlinkerremote;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final UUID SERVICE = UUID.fromString("000018f0-0000-1000-8000-00805f9b34fb");
    private static final UUID RX = UUID.fromString("00002af0-0000-1000-8000-00805f9b34fb");
    private static final UUID TX = UUID.fromString("00002af1-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx, rx;
    private TextView status, log;
    private Button connect, lock, unlock, preheatOn, preheatOff;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ready = false;

    static class Step {
        final String s; final long wait;
        Step(String s, long wait) { this.s=s; this.wait=wait; }
    }

    // Exact wake-up sequence used in the successful nRF Connect macros.
    private final Step[] WAKE = new Step[] {
        new Step("ATE0",200),
        new Step("STP 61",150),
        new Step("STPO",150),
        new Step("STCSWM 2",30),
        new Step("ATSH100",50),
        new Step("ATRTR",20),
        new Step("STCSWM 3",200),
        new Step("ATSH621",50),
        new Step("00FFFFFFFFFF0000",720),
        new Step("STP 62",150),
        new Step("STPO",150),
        new Step("ATSH1024E097",50)
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter=bm.getAdapter();
        requestBlePermissions();
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32,32,32,32);
        sv.addView(l);

        TextView title=new TextView(this);
        title.setText("Ampera-e Remote");
        title.setTextSize(28); title.setTextColor(Color.BLACK);
        title.setPadding(0,0,0,24);
        l.addView(title);

        status=new TextView(this);
        status.setText("vLinker: getrennt");
        status.setTextSize(18); status.setPadding(0,0,0,20);
        l.addView(status);

        connect=button("vLinker verbinden");
        l.addView(connect);
        connect.setOnClickListener(v -> startScan());

        lock=button("🔒  Verriegeln");
        unlock=button("🔓  Entriegeln");
        preheatOn=button("🔥  Preheat ON");
        preheatOff=button("⛔  Preheat OFF");
        l.addView(lock); l.addView(unlock); l.addView(preheatOn); l.addView(preheatOff);

        setCommandEnabled(false);
        lock.setOnClickListener(v -> confirm("Fahrzeug verriegeln?", () ->
            sendVehicle(new Step[]{new Step("0001FF",180),new Step("0C00FF",1250),new Step("0000FF",0)})));
        unlock.setOnClickListener(v -> confirm("Fahrzeug entriegeln?", () ->
            sendVehicle(new Step[]{new Step("0003FF",180),new Step("0C00FF",1250),new Step("0000FF",0)})));
        preheatOn.setOnClickListener(v -> confirm("Preheat einschalten?", () ->
            sendVehicle(new Step[]{new Step("8001FF",360),new Step("0000FF",0)})));
        preheatOff.setOnClickListener(v -> confirm("Preheat ausschalten?", () ->
            sendVehicle(new Step[]{new Step("4001FF",360),new Step("0000FF",0)})));

        TextView lt=new TextView(this); lt.setText("Antworten"); lt.setTextSize(17); lt.setPadding(0,24,0,8);
        l.addView(lt);
        log=new TextView(this); log.setTextSize(13); log.setTextIsSelectable(true);
        l.addView(log);
        setContentView(sv);
    }

    private Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(18);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,150);
        p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    private void confirm(String msg, Runnable yes) {
        new AlertDialog.Builder(this).setTitle("Bestätigen").setMessage(msg)
            .setNegativeButton("Abbrechen",null)
            .setPositiveButton("Senden",(d,w)->yes.run()).show();
    }

    private void requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},10);
        } else if (Build.VERSION.SDK_INT < 31 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},11);
        }
    }

    private boolean permissionsOk() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
                   checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }

    private void startScan() {
        if (!permissionsOk()) { requestBlePermissions(); return; }
        if (adapter==null || !adapter.isEnabled()) {
            status.setText("Bluetooth bitte einschalten"); return;
        }
        status.setText("Suche vLinker MC-IOS …");
        scanner=adapter.getBluetoothLeScanner();
        scanner.startScan(scanCb);
        h.postDelayed(() -> {
            try { if(scanner!=null) scanner.stopScan(scanCb); } catch(Exception ignored){}
            if(gatt==null) status.setText("vLinker nicht gefunden – erneut versuchen");
        },10000);
    }

    private final ScanCallback scanCb=new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult r) {
            BluetoothDevice d=r.getDevice();
            String name=null;
            try { name=d.getName(); } catch(Exception ignored){}
            if(name==null && r.getScanRecord()!=null) name=r.getScanRecord().getDeviceName();
            if(name!=null && name.toLowerCase(Locale.ROOT).contains("vlinker")) {
                try { scanner.stopScan(this); } catch(Exception ignored){}
                status.setText("Verbinde mit "+name+" …");
                gatt=d.connectGatt(MainActivity.this,false,gattCb,BluetoothDevice.TRANSPORT_LE);
            }
        }
        @Override public void onScanFailed(int e) { status.setText("BLE Scan Fehler: "+e); }
    };

    private final BluetoothGattCallback gattCb=new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g,int st,int ns) {
            runOnUiThread(() -> {
                if(ns==BluetoothProfile.STATE_CONNECTED) {
                    status.setText("Verbunden – Dienste werden geladen …");
                    g.discoverServices();
                } else {
                    ready=false; setCommandEnabled(false); status.setText("vLinker: getrennt");
                }
            });
        }

        @Override public void onServicesDiscovered(BluetoothGatt g,int st) {
            BluetoothGattService s=g.getService(SERVICE);
            if(s==null){ runOnUiThread(()->status.setText("BLE Service 18F0 nicht gefunden")); return; }
            tx=s.getCharacteristic(TX); rx=s.getCharacteristic(RX);
            if(tx==null||rx==null){ runOnUiThread(()->status.setText("2AF0/2AF1 nicht gefunden")); return; }

            g.setCharacteristicNotification(rx,true);
            BluetoothGattDescriptor d=rx.getDescriptor(CCCD);
            if(d!=null) {
                if(Build.VERSION.SDK_INT>=33) g.writeDescriptor(d,BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE); g.writeDescriptor(d); }
            }
            h.postDelayed(() -> runOnUiThread(() -> {
                ready=true; setCommandEnabled(true);
                status.setText("vLinker: verbunden ✓");
            }),400);
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value) {
            String s=new String(value,StandardCharsets.US_ASCII).replace("\r","\\r").replace("\n","\\n");
            runOnUiThread(()->appendLog("← "+s));
        }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c) {
            if(Build.VERSION.SDK_INT<33) {
                String s=new String(c.getValue(),StandardCharsets.US_ASCII).replace("\r","\\r").replace("\n","\\n");
                runOnUiThread(()->appendLog("← "+s));
            }
        }
    };

    private void setCommandEnabled(boolean x) {
        if(lock!=null){ lock.setEnabled(x); unlock.setEnabled(x); preheatOn.setEnabled(x); preheatOff.setEnabled(x); }
    }

    private void sendVehicle(Step[] command) {
        if(!ready||tx==null){ status.setText("Zuerst vLinker verbinden"); return; }
        setCommandEnabled(false);
        status.setText("Sende Wake-up + Befehl …");
        ArrayList<Step> all=new ArrayList<>(Arrays.asList(WAKE));
        all.addAll(Arrays.asList(command));
        AtomicInteger idx=new AtomicInteger(0);
        sendNext(all,idx);
    }

    private void sendNext(ArrayList<Step> steps, AtomicInteger idx) {
        int i=idx.getAndIncrement();
        if(i>=steps.size()) {
            status.setText("Befehl gesendet ✓");
            setCommandEnabled(true);
            return;
        }
        Step st=steps.get(i);
        writeAscii(st.s+"\r");
        h.postDelayed(() -> sendNext(steps,idx),Math.max(80,st.wait));
    }

    private void writeAscii(String s) {
        appendLog("→ "+s.trim());
        byte[] data=s.getBytes(StandardCharsets.US_ASCII);
        if(Build.VERSION.SDK_INT>=33) gatt.writeCharacteristic(tx,data,BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        else { tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); tx.setValue(data); gatt.writeCharacteristic(tx); }
    }

    private void appendLog(String s) {
        log.append(s+"\n");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if(gatt!=null){ gatt.disconnect(); gatt.close(); } } catch(Exception ignored){}
    }
}
